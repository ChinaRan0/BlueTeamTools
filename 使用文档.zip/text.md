# 蓝队工具箱使用手册

## 文档目的

群里的师傅有很多工具找不到使用文档，特此专门写了这个文档，用于各位师傅查询

## 工具使用

### everything

everthing软件-是一个强大的文件搜索工具,它体积小巧,界面简洁易用,快速建立索引,能够以极快的速度帮助用户找到计算机上的文件和文件夹,无限提升效率

使用方法：

直接打开即可

###  Process Hacker：一款用于调试和排除软件故障的强大工具

Process Hacker是一款针对高级用户的安全分析工具，它可以帮助研究人员检测和解决软件或进程在特定操作系统环境下遇到的问题。除此之外，它还可以检测恶意进程，并告知我们这些恶意进程想要实现的功能。
当你运行Process Hacker之后，你将会看到如下图所示的主界面：

工具主界面

![1542988800_5bf82400727b4](assets/1542988800_5bf82400727b4.png)

默认配置下，它会在Processes标签页中以树形图的形式显示所有当前正在运行的进程列表：![查看到更多详细的信息](https://image.3001.net/images/20181124/1542988814_5bf8240ea54da.png!small)

-进程标识符（PID）

-CPU使用占比（CPU）

-I/O总速率

-私有字节

-运行进程的用户名

-进程简单描述

点击特定的进程名之后，你可以查看到更多详细的信息：

查看到更多详细的信息

Services标签页主要显示当前服务和驱动的详细列表，Network标签页和Disk标签页分别显示的是各个进程对应的网络使用情况和磁盘使用情况。

![网络使用情况和磁盘使用情况](https://image.3001.net/images/20181124/1542988822_5bf8241652e03.png!small)

网络使用情况和磁盘使用情况大家可以在Hacker>Options设置中的Highlighting标签下修改标记颜色：

修改标记颜色

释放控制
Process Hacker给你提供的每一个选项都可以帮助你删掉那些原本删不掉的文件，之所以删不掉，是因为有其他的进程在使用它们…

Process Hacker可以帮助我们识别目标进程，并切断进程跟文件之间的关联，整个处理过程如下：

1、 在主菜单中点击“Find handles orDLLs”；

2、 在Filter栏中输入完整或部分文件名，然后点击“Find”；

3、 在结果中找到正确的文件名，然后点击那一行；

4、 点击鼠标右键，从菜单栏中选择“Go toowning process”；

5、 Processes窗口中会高亮标记这个进程；

6、 右键点击高亮进程，选择“Terminate”；

7、 终止进程之后，你就可以尝试删除之前被锁定的文件了；

浏览网络信息
在Process Hacker的帮助下，大家还可以浏览特定进程的网络通信情况，即使你关闭了某些进程，你还可以启用“Restore previous session”功能来查看所有的进程通信数据：

查看所有的进程通信数据

从内存中导出字符串信息
你可以使用Process Hacker来导出内存中的进程数据，分析人员可以使用这些导出数据来搜索内存中的字符串信息，然后使用脚本或Yara规则来对目标进程进行初始分类。如果目标应用是恶意软件，那我们很快就会发现它们。

右键点击正在运行的目标进程，选择“Create dump file…”，选择导出数据的保存路径。ProcessHacker从内存中导出的数据文件带有.dmp后缀，大家可以使用十六进制编辑器或文本编辑器（或mimikatz）来浏览这些文件。



### Getinfo

获取系统基本信息

![image-20231220134910564](assets/image-20231220134910564.png)

直接打开使用

### 红队服务器探测

教程：

https://mp.weixin.qq.com/s/GvYDnwvtEMI91bVYbvE5WA

### 哈希计算器

用于取证时，保证文件完整性

![image-20231220135047852](assets/image-20231220135047852.png)

使用方法：直接将文件拖入即可

### Burp精简版

老版本的Burp,保持基本功能可以使用。

直接单机打开即可

![image-20231220135149367](assets/image-20231220135149367.png)

### notepad++

更加强大的文本编辑工具

使用方法：直接打开即可

![image-20231220135328827](assets/image-20231220135328827.png)

### ASCII及进制转化器

可以转换ASCII以及进制的互相转换和子网划分辅助

使用方法：直接打开即可

![image-20231220135435018](assets/image-20231220135435018.png)

### 二维码解析工具

用于解析二维码，并且进行二维码生成的一款工具

![image-20231220135526673](assets/image-20231220135526673.png)

使用方法：直接打开即可

### MobaXterm(万能连接工具)

用于连接：SSH/Telnet/Rsh/Xdmcp/RDP/VNC/FTP/SFTP/串口/文件/shell/浏览器/Mosh/AwsS3/WSL

使用密码：qaz1230.

![image-20231220135618518](assets/image-20231220135618518.png)

![image-20231220135645382](assets/image-20231220135645382.png)



使用方法：直接打开即可

### 内网通

**网通是指一种能够在局域网或内网中实现电脑之间通信的软件。**通过内网通软件,用户可以在局域网内,不需要通过公网中转,直接进行文件传输、聊天等操作,快速高效。

使用方法：直接打开即可看到安装包

根据操作一步步安装即可

### 自动刷新脚本

模拟浏览器自动刷新，（看监控设备的时候懒）

使用方法：直接打开即可

![image-20231220135953126](assets/image-20231220135953126.png)

![image-20231220135959024](assets/image-20231220135959024.png)

### 模拟EXE钓鱼工具

适用于攻防演练前蓝方自行进行内部钓鱼模拟

使用方法：

https://mp.weixin.qq.com/s/D5wYdmartiG6wE_SRqI0hA

### 超级解密工具

用于解密各种密文，以及现代密码

![image-20231220140302553](assets/image-20231220140302553.png)

![image-20231220140324518](assets/image-20231220140324518.png)

使用方法：直接打开即可

### 蓝队分析辅助包

流量分析解密工具（开发者ABC_123）

使用教程：https://mp.weixin.qq.com/s/4RnLQM8pvsVQiZe6cGW-Ww

### Wireshark

Wireshark（前身 Ethereal）是一个网络包分析工具。该工具主要是用来捕获网络数据包，并自动解析数据包，为用户显示数据包的详细信息，供用户对数据包进行分析。

Wireshark常用语句：

过滤需要的IP地址 ip.addr==

在数据包过滤的基础上过滤协议ip.addr==[http://xxx.xxx.xxx.xxx](https://link.zhihu.com/?target=http%3A//xxx.xxx.xxx.xxx) and tcp

过滤端口ip.addr==[http://xxx.xxx.xxx.xxx](https://link.zhihu.com/?target=http%3A//xxx.xxx.xxx.xxx) and http and tcp.port==80

指定源地址 目的地址ip.src==[http://xxx.xxx.xxx.xxx](https://link.zhihu.com/?target=http%3A//xxx.xxx.xxx.xxx) and ip.dst==[http://xxx.xxx.xxx.xxx](https://link.zhihu.com/?target=http%3A//xxx.xxx.xxx.xxx)

SEQ字段（序列号）过滤（定位丢包问题）

使用方法：

打开Wireshark

选择要抓包的网络接口

![image-20231220141022350](assets/image-20231220141022350.png)

![image-20231220141034666](assets/image-20231220141034666.png)

在上方应用显示过滤器输入语句即可

### 科莱网络分析

科来网络全流量安全分析系统（TSA），是基于网络全流量分析技术，旁路采集、分析和存储所有网络流量，通过威胁情报系统检测已知威胁，通过回溯分析数据包特征、异常网络行为，发现潜伏已久的高级未知攻击。TSA具备多维的数据分析及深度挖掘能力，能够实现数据包级的追踪取证。网络全流量分析技术是发现APT网络攻击的重要技术手段，帮助用户建立自适应网络安全架构。

使用教程：

https://blog.csdn.net/weixin_43263566/article/details/127923455

### Fiddler工具

Fiddler是一个http协议调试代理工具，它能够记录并检查所有你的电脑和互联网之间的http通讯，设置断点，查看所有的“进出”Fiddler的数据（指cookie,html,js,css等文件）。

使用方法：

直接打开即可

![image-20231220141418979](assets/image-20231220141418979.png)

### Autoruns(检查启动项服务等等)

类似于火绒剑，在此不讲解

### D盾

『D盾_IIS防火墙』专为IIS设计的一个主动防御的保护软件,以内外保护的方式 防止网站和服务器给入侵,在正常运行各类网站的情 况下，越少的功能，服务器越安全的理念而设计！ 限制了常见的入侵方法

![image-20231220141605517](assets/image-20231220141605517.png)

使用方法：http://d99net.net/News.asp?id=106

### Java内存马扫描工具

使用方法：

只需要将tomcat-memshell-scanner.jsp放在可能被注入内存马的web录下，然后使用浏览器访问即可直接获得扫描结果。

### LastActivityView

用于查看近期更改的文件（应急用，查看黑客做了哪些手脚）

使用方法：直接打开即可

ARK工具YDArk中文版是一款免费的64位Windows系统内核辅助工具的系统底层反内核工具的系统安全辅助工具.功能包括:系统动作分析,系统内核,应用层钩子,内核钩子扫描,文件管理(强制删除任意文件),进程管理,启动项管理,注册表管理,服务管理,驱动模块,网络管理,系统杂项修复等.主要用于分析系统底层信息解决系统问题.

![image-20231220142113937](assets/image-20231220142113937.png)

使用方法：直接打开即可

### 火绒剑

安服仔必会神器，在此不进行阐述。

### 端口专家

查看那个程序开放卡哪个端口

### WebShell查杀工具

深信服WebShell查杀工具/河马WebShell查杀工具/D盾

### annamineWanncry挖矿专杀工具

使用方法：

选择合适自己系统架构的版本，直接运行即可

![image-20231220142457156](assets/image-20231220142457156.png)

### BrowsingHistoryView浏览器记录查看工具

用于取证所有浏览器的浏览记录

使用方法：

直接打开即可

![image-20231220142741915](assets/image-20231220142741915.png)

### evtxLogparse

一款windows安全日志分析工具

使用方法：

```sh
evtxLogparse.exe -h
```

![image-20231220143010353](assets/image-20231220143010353.png)

### Sysmon64 监控系统日志

微软官方文档：https://learn.microsoft.com/zh-cn/sysinternals/downloads/sysmon

### dumpclass

从java进程里dump出类的class文件的小工具

使用教程

https://blog.csdn.net/hengyunabc/article/details/51106980

### SEO爬虫分析工具

秋式网站日志分析工具/金花日志分析工具

### D-Eyes绿盟科技应急响应工具

使用文档

https://www.bilibili.com/read/cv27726604/

## 文档获取方式

后台回复："蓝队文档"即可
后台回复“交流去”获取技术交流群链接